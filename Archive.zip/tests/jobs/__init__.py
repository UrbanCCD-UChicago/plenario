import random

RANDOM_NAME = 'TEST{}'.format(random.randint(0, 9999))
