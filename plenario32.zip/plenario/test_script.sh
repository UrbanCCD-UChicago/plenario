if [ -n "$WORKER" ]; then	
		echo "Quitting";
		exit;
fi
echo "Made it";
